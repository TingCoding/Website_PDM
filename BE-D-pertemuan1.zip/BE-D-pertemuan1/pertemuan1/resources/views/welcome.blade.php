<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pertemuan 1</title>
    <style>
        h1 {
            color: blue;
        }
    </style>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Pertemuan 1</h1>
    <h2>Pertemuan 1</h2>
    <h3>Pertemuan 1</h3>
    <h4>Pertemuan 1</h4>
    <h5>Pertemuan 1</h5>
    <h6>Pertemuan 1</h6>

    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime unde neque exercitationem doloremque molestias ex aperiam illo itaque dignissimos numquam debitis tempora ipsum nihil possimus aliquam animi ut, cupiditate atque. Molestiae illum doloribus asperiores harum, facere labore eius ducimus laborum! Consectetur doloremque, atque impedit reprehenderit sed qui blanditiis iste obcaecati, consequuntur, sequi ea eos recusandae? Tempore repudiandae pariatur repellendus tenetur sint! Quos consequuntur itaque dolorem deleniti illum voluptate corrupti rerum recusandae doloremque, minima voluptatum! Obcaecati, consequatur beatae. Magni cupiditate maxime aliquid fuga, qui libero sapiente culpa amet ex dicta a totam necessitatibus pariatur illum asperiores odit iure. Voluptates, dolore odio? Facilis consequatur vel, beatae possimus nemo, eveniet provident necessitatibus alias atque debitis aspernatur corrupti ullam molestiae pariatur distinctio in eaque. Aperiam porro unde ipsam blanditiis iste nihil et magnam harum, non hic maiores reiciendis dolorem dolorum dicta quod repudiandae sunt quae in rerum numquam optio, fugiat dolore aspernatur repellendus! Libero quia dolorem repellendus voluptatibus quod eius quidem nostrum commodi provident consequuntur nemo minima hic optio, corporis, rem quaerat consequatur incidunt eveniet. Beatae, nesciunt eaque? Amet fugiat sint blanditiis natus reiciendis porro iste laborum, recusandae ut sequi assumenda modi perspiciatis hic facilis necessitatibus vero adipisci officiis nobis ex atque. Quam, porro?</p>

    <a href="https://google.com">Link Google</a>

    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHcAAAB3CAMAAAAO5y+4AAAAk1BMVEX////lGDfiAAD63N3rb3vkACPkACXlFDXrbXnkACr2wsb52dr2xcnjABvlDTLjABj74+X++PnjABH98fLugoz40tXzsLbyoqjnOU7tfIX86uvxnaTsdH/sfID0tbrrYG7uio/pUWLoSFfqaXHpW2PmK0PpWGjmJj3wkJj0u73nQU7lMj/wlp3oUFvyqa3pZGfkIzDus2eQAAAEsElEQVRoge2a23aqOhRAI5qEgAl3RLEoUrTuWuv/f92BJNys7a6ocexxmE8CMZPAYuUCAAwMDPyv8OxgaiRhGCb7aWB7D/fZxnG9yl1Ncy1KIYdaxaaWr/yjYT9CaSbrqFAhwvDoK5gRVJxD5CfBHZ3BcXsikLDaglkbXJ8JK0qd0mPg3O5cGMucQNnIslnUhaNok75mgtfXTbSDLi1OS/gxg+Rd3y9ukiarHSWyOmSR6HUZG6a98JxWixxvYZvGbPkaMQuJE8SE7rZhT7UTZCPK6ymagPKPt+n458j17OkhzRGU/6Esm/YI9cXOraRsEweiBscz97H/EnZK7pd+nASeuAReMPvAldpl4+vFaRlHDKFVIi6YefTTkebSIqStaatcQEl51zWczmcmly/2GUHlv3HeI8IMFxMtTXhDg8PWcmH9DGHa3DsPVTsZQ66bHvg5OclWI5iG39T9I3/gweNVTDSreYjEA3OqS72fHSGWloVlM72YnL6t+yd4m4zMgt2aRfUfstCKXDiIrNW+rqEH9mGHLkhLoM9LHOjlwwzht95500PwS1LEVXbi986gZ3tbBZHVO3cYLW+ROKjFQ0vmLhiAMZG/y0wGLYpayRvTpK8WgLAOVvi+io3AHNu2Ie8oy4NI3gRi2PbYDIw4i2D9h1l/bZETGK+asbBOPYtcVs2Y1OK8vqLOfiT+QG5obYm9KVsA2zHycR5qdXDz0yqvNYzM27QFM4uQQ3tH9sWbtQ8fEXEP4A44a63zSMTozIvi9mFP8+818ulm2cA683bSdSG+k/UcG5554UNGVl/wom6SwNHjR5Scz7Ou4FONFvjdvoDMFXnD7g2GR0XesdvxurfniN/hdR9gqCisgLNpBxbb3GGY/jteOt6JKi04tAOavCnzGu3RDd0r8y60lle7aSp0FU57PIOUhRUA2yawWKpOC9ZNYDFVWbJk1mSObqf/YIImU551+o/FaQJaUxhWAIyqgMZEpbYZU7KtUm+dKclaqTepun7Ya2rdG7sKaEtVpy+pAlpTqwVycqY4nAGYi8BiK8Xeo8iU5KZZbg+mwovUdfqChXiQFE2NWvAVCAxVa+UyYqTcy7t+ZVOjBp4plU2NGoKyvUhlpy/w+GqZujFszXvh3anXAp2pHcNWFGNKhVOjhilVOTVqGDNM7vl27Lc4Ods9IZwB2LA/z9CCOcz+XugBhJrKqVFDoKnPkiU27vEW7g44n6oWrs5YP0cLnpE1BgYGBgYGBgb+RRxzXCO+5DIbxJSoVYBve2ZnbNk6fMWY0zlpBW75QaZ24v/ztRoxZh7V22JFJ9Y6KyxZffiqj4O8ta7rIzbR9epTjJkuWMrl5ogsORO57D1zu+vfcSbKz69fz4t+WlqO3O72ubc/TttrNIjrHNFpxSVvUB+dXvuap+M9aJbAlW8/cyJ3QHTJu6USSK+90B0vSOYSWc2bL8H4kndFshdOTm7zfkvt7XxvtarWh7e3eb88v2BhBgWmWXtjWzAWXjlFTa/35i3vunl+RT1HKjeJeLERW5bcseHNdCvv9fd33V69CPUJZynqs9NJDd+xz8SG7vP4fcukbq0/ZclnYGBg4N/nP9n3TIvOdCz2AAAAAElFTkSuQmCC" alt="Gambar mobil tesla" style="width: 500px; height: 500px;">

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, sequi?</p>
    <br><br><br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, sequi?</p>
    <hr>

    <form action="">
        <label for="">Name</label>
        <input type="text">

        <button>Submit</button>
    </form>

    <table>
        <tr>
            <th>Name</th>
            <th>NIM</th>
        </tr>
        <tr>
            <td>Hanson</td>
            <td>12345</td>
        </tr>
    </table>

    <div class="div1">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam inventore minus magni vero provident aliquam consequuntur? Beatae, quam deserunt corporis adipisci, animi dolorem quibusdam, quo eum corrupti tempora praesentium voluptatem.</p>
    </div>

    <div id="div2">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam inventore minus magni vero provident aliquam consequuntur? Beatae, quam deserunt corporis adipisci, animi dolorem quibusdam, quo eum corrupti tempora praesentium voluptatem.</p>
    </div>
</body>
</html>